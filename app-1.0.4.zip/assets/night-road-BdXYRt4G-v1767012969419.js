const s="/assets/night-road.svg";export{s as _};
