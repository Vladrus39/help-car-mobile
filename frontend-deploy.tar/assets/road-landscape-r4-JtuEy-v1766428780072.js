const s="/assets/road-landscape.svg";export{s as _};
